const badgeTexts = {};

function setBadgeColor(tabId, ttfb) {
  if (ttfb < 0) {
    chrome.action.setBadgeBackgroundColor({tabId: tabId, color: "#C0C0C0"});
    chrome.action.setBadgeTextColor({tabId: tabId, color: "#333333"});
  } else if (ttfb < 200) {
    chrome.action.setBadgeBackgroundColor({tabId: tabId, color: "#00b300"});
    chrome.action.setBadgeTextColor({tabId: tabId, color: "#ffffff"});
  } else if (ttfb < 500) {
    chrome.action.setBadgeBackgroundColor({tabId: tabId, color: "#ffa31a"});
    chrome.action.setBadgeTextColor({tabId: tabId, color: "#333333"});
  } else {
    chrome.action.setBadgeBackgroundColor({tabId: tabId, color: "#ff1a1a"});
    chrome.action.setBadgeTextColor({tabId: tabId, color: "#ffffff"});
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeBackgroundColor({color: "#C0C0C0"});
  chrome.action.setBadgeTextColor({color: "#333333"});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.action === "getTabId") {
	  sendResponse({tabId: sender.tab.id});
	} else if (message.tabId && message.ttfb) {
	  const tabId = message.tabId;
	  const ttfb = message.ttfb*1000;
	  setBadgeColor(tabId, ttfb);
	  badgeTexts[tabId] = `${(ttfb).toFixed(0)}`;
	  chrome.action.setBadgeText({tabId: tabId, text: badgeTexts[tabId]});
	} else if (message.action === "getTtfbValue" && message.tabId) {
	  sendResponse({ttfb: badgeTexts[message.tabId]});
	}
  });
  