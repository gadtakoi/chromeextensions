chrome.runtime.sendMessage({action: "getTabId"}, function(response) {
	if (performance && performance.getEntriesByType('navigation').length > 0) {
	  const timing = performance.getEntriesByType('navigation')[0];
	  const ttfb = (timing.responseStart - timing.requestStart) / 1000;
	  chrome.runtime.sendMessage({tabId: response.tabId, ttfb: ttfb});
	}
  });
  