function setTtfbPointPosition(ttfbValue) {
  const slider = document.getElementById("ttfbSlider");
  const ttfbPoint = document.getElementById("ttfbPoint");
  const ttfbLabel = document.getElementById("ttfbValue");
  const sliderWidth = slider.clientWidth;

  // Positionnez les pas du slider
  const step200ms = document.getElementById("step200ms");
  const step500ms = document.getElementById("step500ms");
  const step1s = document.getElementById("step1s");
  step200ms.style.left = `${sliderWidth * 0.2}px`;
  step500ms.style.left = `${sliderWidth * 0.5}px`;
  step1s.style.left = `${sliderWidth}px`;

  // Si ttfbValue est null, masquez le point et le label
  if (ttfbValue === null) {
    ttfbPoint.classList.remove('visible');
    ttfbLabel.classList.remove('visible');
    return;
  }

  let position;
  if (ttfbValue > 1000) {
    position = sliderWidth;
  } else {
    position = sliderWidth * (ttfbValue / 1000);
  }

  // Calculer la position avant de rendre visible
  ttfbPoint.style.left = `${position}px`;
  ttfbLabel.style.left = `${position}px`;

  // Appliquer la classe de couleur appropriée
  ttfbPoint.classList.remove('good', 'warning', 'bad');
  if (ttfbValue <= 200) {
    ttfbPoint.classList.add('good');
  } else if (ttfbValue <= 500) {
    ttfbPoint.classList.add('warning');
  } else {
    ttfbPoint.classList.add('bad');
  }

  // Mettez à jour le texte du label
  ttfbLabel.innerText = `${ttfbValue} ms`;

  // Petit délai pour assurer que les positions sont appliquées avant l'animation
  requestAnimationFrame(() => {
    ttfbPoint.classList.add('visible');
    ttfbLabel.classList.add('visible');
  });
}

chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
  const tabId = tabs[0].id;
  chrome.runtime.sendMessage({action: "getTtfbValue", tabId: tabId}, (response) => {
    if (response && response.ttfb) {
      const ttfbValue = parseFloat(response.ttfb);
      document.getElementById("ttfbValue").innerText = response.ttfb;
      document.getElementById("ttfbSlider").value = ttfbValue;
      setTtfbPointPosition(ttfbValue);
    } else {
      // S'il n'y a pas de valeur de ttfb, masquez le point et le label
      setTtfbPointPosition(null);
    }
  });
});